# bluechat_uls
Proyecto de Chat En Android Studio con lenguaje de programación JAVA y como gestor de base de datos Firebase y utilizando su autentificación con número de teléfono estilo WhatsApp para la materia de Proyectos de Aplicaciones Móviles de La Universidad Luterana Salvadoreña.
